Send datatype size: 8
Recv datatype size: 8
Comm size: 4

Send counts
0 0 0 0 
0 0 0 0 
0 0 0 0 
0 0 0 0 


Recv counts
0 0 0 0 
1 1 1 1 
0 0 0 0 
0 0 0 0 