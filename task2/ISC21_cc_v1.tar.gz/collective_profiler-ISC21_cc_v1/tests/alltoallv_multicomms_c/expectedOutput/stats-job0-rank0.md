Total number of alltoallv calls: 3

# Datatypes

3/3 calls use a datatype of size 4 while sending data
3/3 calls use a datatype of size 4 while receiving data

# Communicator size(s)

1/3 calls use a communicator size of 4
2/3 calls use a communicator size of 2

# Message sizes

0/24 of all messages are large (threshold = 200)
24/24 of all messages are small (threshold = 200)
16/24 of all messages are small, but not 0-size (threshold = 200)

# Sparsity

1/3 of all calls have 4 send counts equals to zero
2/3 of all calls have 2 send counts equals to zero
1/3 of all calls have 4 recv counts equals to zero
2/3 of all calls have 2 recv counts equals to zero

# Min/max
3/3 calls have a send count min of 0

3/3 calls have a recv count min of 0

3/3 calls have a send count min of 0 (excluding zero)

3/3 calls have a recv count min of 0 (excluding zero)

1/3 calls have a send count max of 3
2/3 calls have a send count max of 1

1/3 calls have a recv count max of 3
2/3 calls have a recv count max of 1

