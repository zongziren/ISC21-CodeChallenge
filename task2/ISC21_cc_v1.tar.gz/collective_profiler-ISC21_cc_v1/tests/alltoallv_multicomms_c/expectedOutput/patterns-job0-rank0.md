# Patterns
## Pattern #0 (2/3 alltoallv calls)

Alltoallv calls: 0,2

2 ranks sent to 1 other ranks

1 ranks recv'd from 2 other ranks


## Pattern #1 (1/3 alltoallv calls)

Alltoallv calls: 1

4 ranks sent to 3 other ranks

3 ranks recv'd from 4 other ranks


