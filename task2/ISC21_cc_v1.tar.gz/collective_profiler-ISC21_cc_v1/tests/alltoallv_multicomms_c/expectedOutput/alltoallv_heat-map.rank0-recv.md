FORMAT_VERSION: 9

# Call 0:
Rank 0: 0 bytes
Rank 1: 8 bytes
# Call 1:
Rank 0: 0 bytes
Rank 1: 16 bytes
Rank 2: 32 bytes
Rank 3: 48 bytes
# Call 2:
Rank 0: 0 bytes
Rank 1: 8 bytes

