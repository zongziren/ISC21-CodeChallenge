FORMAT_VERSION: 9

# Call 0:
Rank 0: 0 bytes
Rank 1: 8 bytes
# Call 2:
Rank 0: 0 bytes
Rank 1: 8 bytes

