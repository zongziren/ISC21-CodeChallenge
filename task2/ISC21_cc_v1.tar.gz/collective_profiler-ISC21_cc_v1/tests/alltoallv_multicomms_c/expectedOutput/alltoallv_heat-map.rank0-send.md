FORMAT_VERSION: 9

# Call 0:
Rank 0: 4 bytes
Rank 1: 4 bytes
# Call 1:
Rank 0: 24 bytes
Rank 1: 24 bytes
Rank 2: 24 bytes
Rank 3: 24 bytes
# Call 2:
Rank 0: 4 bytes
Rank 1: 4 bytes

