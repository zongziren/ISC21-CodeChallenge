FORMAT_VERSION: 9

# Call 0:
Rank 0: 4 bytes
Rank 1: 4 bytes
# Call 2:
Rank 0: 4 bytes
Rank 1: 4 bytes

