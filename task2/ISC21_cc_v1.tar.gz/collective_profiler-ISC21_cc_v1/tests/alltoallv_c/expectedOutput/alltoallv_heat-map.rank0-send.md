FORMAT_VERSION: 9

# Call 0:
Rank 0: 24 bytes
Rank 1: 24 bytes
Rank 2: 24 bytes
Rank 3: 24 bytes

