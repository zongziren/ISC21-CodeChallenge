# Patterns
## Pattern #0 (1/1 alltoallv calls)

Alltoallv calls: 0

4 ranks sent to 3 other ranks

3 ranks recv'd from 4 other ranks


