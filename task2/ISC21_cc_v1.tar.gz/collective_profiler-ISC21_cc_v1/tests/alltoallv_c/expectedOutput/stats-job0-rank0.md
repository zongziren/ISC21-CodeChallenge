Total number of alltoallv calls: 1

# Datatypes

1/1 calls use a datatype of size 4 while sending data
1/1 calls use a datatype of size 4 while receiving data

# Communicator size(s)

1/1 calls use a communicator size of 4

# Message sizes

0/16 of all messages are large (threshold = 200)
16/16 of all messages are small (threshold = 200)
12/16 of all messages are small, but not 0-size (threshold = 200)

# Sparsity

1/1 of all calls have 4 send counts equals to zero
1/1 of all calls have 4 recv counts equals to zero

# Min/max
1/1 calls have a send count min of 0

1/1 calls have a recv count min of 0

1/1 calls have a send count min of 0 (excluding zero)

1/1 calls have a recv count min of 0 (excluding zero)

1/1 calls have a send count max of 3

1/1 calls have a recv count max of 3

