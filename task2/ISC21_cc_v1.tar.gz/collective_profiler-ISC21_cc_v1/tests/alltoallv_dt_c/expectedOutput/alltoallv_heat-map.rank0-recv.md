FORMAT_VERSION: 9

# Call 0:
Rank 0: 16 bytes
Rank 1: 16 bytes
Rank 2: 16 bytes
Rank 3: 16 bytes
# Call 1:
Rank 0: 32 bytes
Rank 1: 32 bytes
Rank 2: 32 bytes
Rank 3: 32 bytes

