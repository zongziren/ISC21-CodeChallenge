
# N to n patterns

## Pattern #0 (2/2 alltoallv calls)

Alltoallv calls: 0-1

4 ranks sent to 4 other ranks

4 ranks recv'd from 4 other ranks


