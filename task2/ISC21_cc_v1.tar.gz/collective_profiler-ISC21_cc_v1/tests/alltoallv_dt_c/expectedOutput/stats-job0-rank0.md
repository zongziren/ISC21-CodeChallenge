Total number of alltoallv calls: 2

# Datatypes

1/2 calls use a datatype of size 4 while sending data
1/2 calls use a datatype of size 8 while sending data
1/2 calls use a datatype of size 4 while receiving data
1/2 calls use a datatype of size 8 while receiving data

# Communicator size(s)

2/2 calls use a communicator size of 4

# Message sizes

0/32 of all messages are large (threshold = 200)
32/32 of all messages are small (threshold = 200)
32/32 of all messages are small, but not 0-size (threshold = 200)

# Sparsity

2/2 of all calls have 0 send counts equals to zero
2/2 of all calls have 0 recv counts equals to zero

# Min/max
2/2 calls have a send count min of 1

2/2 calls have a recv count min of 1

2/2 calls have a send count min of 0 (excluding zero)

2/2 calls have a recv count min of 0 (excluding zero)

2/2 calls have a send count max of 1

2/2 calls have a recv count max of 1

