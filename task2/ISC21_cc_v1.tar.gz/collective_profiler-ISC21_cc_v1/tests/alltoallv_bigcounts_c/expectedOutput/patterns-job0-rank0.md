# Patterns
## Pattern #0 (1000000/1000000 alltoallv calls)

Alltoallv calls: 0-999999

4 ranks sent to 3 other ranks

3 ranks recv'd from 4 other ranks


