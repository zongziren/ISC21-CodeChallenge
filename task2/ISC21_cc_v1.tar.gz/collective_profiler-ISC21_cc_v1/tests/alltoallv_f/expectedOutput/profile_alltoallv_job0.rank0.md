# Summary
COMM_WORLD size: 3
Total number of Alltoallv calls = 2 (limit is 0; -1 means no limit)
# Send/recv counts for Alltoallv operations:

## Data set #0

comm size = 3; Alltoallv calls = 2

### Data sent per rank - Type size: 4

#### Amount of data per rank
Per-rank data is disabled

#### Number of zeros
Per-rank data is disabled
Total: 0/9 (0.000000%)

#### Data size min/max
DISABLED

#### Small vs. large messages
DISABLED


#### Grouping based on the total amount per ranks

DISABLED

### Data received per rank - Type size: 4

#### Amount of data per rank
Per-rank data is disabled

#### Number of zeros
Per-rank data is disabled
Total: 0/9 (0.000000%)

#### Data size min/max
DISABLED

#### Small vs. large messages
DISABLED


#### Grouping based on the total amount per ranks

DISABLED

