Total number of alltoallv calls: 2

# Datatypes

2/2 calls use a datatype of size 4 while sending data
2/2 calls use a datatype of size 4 while receiving data

# Communicator size(s)

2/2 calls use a communicator size of 3

# Message sizes

0/18 of all messages are large (threshold = 200)
18/18 of all messages are small (threshold = 200)
8/18 of all messages are small, but not 0-size (threshold = 200)

# Sparsity

2/2 of all calls have 5 send counts equals to zero
2/2 of all calls have 5 recv counts equals to zero

# Min/max
2/2 calls have a send count min of 0

2/2 calls have a recv count min of 0

2/2 calls have a send count min of 0 (excluding zero)

2/2 calls have a recv count min of 0 (excluding zero)

2/2 calls have a send count max of 3

2/2 calls have a recv count max of 3

