FORMAT_VERSION: 9

# Call 0:
Rank 0: 12 bytes
Rank 1: 12 bytes
Rank 2: 4 bytes
# Call 1:
Rank 0: 12 bytes
Rank 1: 12 bytes
Rank 2: 4 bytes

