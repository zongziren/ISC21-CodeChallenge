FORMAT_VERSION: 9

# Call 0:
Rank 0: 8 bytes
Rank 1: 8 bytes
Rank 2: 12 bytes
# Call 1:
Rank 0: 8 bytes
Rank 1: 8 bytes
Rank 2: 12 bytes

