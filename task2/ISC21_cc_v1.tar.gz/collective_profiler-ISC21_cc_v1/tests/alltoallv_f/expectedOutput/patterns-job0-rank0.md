# Patterns
## Pattern #0 (2/2 alltoallv calls)

Alltoallv calls: 0-1

1 ranks sent to 2 other ranks

2 ranks sent to 1 other ranks

1 ranks recv'd from 2 other ranks

2 ranks recv'd from 1 other ranks


